// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pFVF	= NULL;
	m_pPs	= NULL;
	m_pTbl	= NULL;	
	
	m_pTx	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)pDev;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER	pShd	= NULL;
	LPD3DXBUFFER	pErr	= NULL;
	hr = D3DXCompileShaderFromFile(	"data/shader.fx"
									, NULL
									, NULL
									, "PxlPrc"
									, "ps_2_0"
									, dwFlags
									, &pShd
									, &pErr
									, &m_pTbl
									);	
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}

	hr = m_pDev->CreatePixelShader( (DWORD*)pShd->GetBufferPointer() , &m_pPs);
	pShd->Release();
	if ( FAILED(hr) )
		return -1;


	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(CShaderEx::VtxRHWDUV1::FVF, vertex_decl);
	if(FAILED(m_pDev->CreateVertexDeclaration( vertex_decl, &m_pFVF )))
		return -1;


	FLOAT	fScnW	= 800;
	FLOAT	fScnH	= 600;

	m_pVtx[0] = VtxRHWDUV1(  -.5f,  -.5f,	 0.f, 0.f );
	m_pVtx[1] = VtxRHWDUV1( fScnW,  -.5f,	 1.f, 0.f );
	m_pVtx[2] = VtxRHWDUV1( fScnW, fScnH,	 1.f, 1.f );
	m_pVtx[3] = VtxRHWDUV1(  -.5f, fScnH,	 0.f, 1.f );

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pFVF	);
	SAFE_RELEASE(	m_pPs	);
	SAFE_RELEASE(	m_pTbl	);
}


INT CShaderEx::FrameMove()
{
	return 0;
}


void CShaderEx::Render()
{
	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE );
    m_pDev->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );

	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);

	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_POINT);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_POINT);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_NONE);


	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_CLAMP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSW, D3DTADDRESS_CLAMP);

	m_pDev->SetVertexDeclaration( m_pFVF );
	m_pDev->SetPixelShader(m_pPs);

	m_pDev->SetFVF(VtxRHWDUV1::FVF);
	m_pDev->SetTexture(0, m_pTx);

	m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxRHWDUV1));
	m_pDev->SetVertexDeclaration( NULL );
	m_pDev->SetPixelShader(NULL);

	m_pDev->SetTexture(0, NULL);

	m_pDev->SetPixelShader( NULL);
}


void CShaderEx::SetSceneTexture(PDTX pTx)
{
	m_pTx = pTx;
}