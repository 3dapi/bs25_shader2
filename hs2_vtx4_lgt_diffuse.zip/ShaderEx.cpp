// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pVs	= NULL;
	m_pFVF	= NULL;
	m_pTbl	= NULL;

	m_pVtx	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();	
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)pDev;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER	pShd	= NULL;
	LPD3DXBUFFER	pErr	= NULL;

	hr = D3DXCompileShaderFromFile(	"data/Shader.fx"
								,	NULL
								,	NULL
								,	"VtxPrc"
								,	"vs_1_1"
								,	dwFlags
								,	&pShd
								,	&pErr
								,	&m_pTbl
								);

	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}

	hr = m_pDev->CreateVertexShader( (DWORD*)pShd->GetBufferPointer() , &m_pVs);
	pShd->Release();
	if ( FAILED(hr) )
		return -1;


	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(VtxN::FVF, vertex_decl);
	if(FAILED(m_pDev->CreateVertexDeclaration( vertex_decl, &m_pFVF )))
		return -1;



	// ���ؽ� ����
	INT	iNSphereSegments	= 128;
	m_iNvx = 2*iNSphereSegments*(iNSphereSegments+1);

	FLOAT fDeltaRingAngle = ( D3DX_PI / iNSphereSegments );
	FLOAT fDeltaSegAngle  = ( 2.0f * D3DX_PI / iNSphereSegments );

	m_pVtx = new CShaderEx::VtxN[m_iNvx];
	CShaderEx::VtxN* pV = m_pVtx;

	// Generate the group of rings for the sphere
	for( DWORD ring = 0; ring < iNSphereSegments; ring++ )
	{
		FLOAT r0 = 50 * sinf( (ring+0) * fDeltaRingAngle );
		FLOAT r1 = 50 * sinf( (ring+1) * fDeltaRingAngle );
		FLOAT y0 = 50 * cosf( (ring+0) * fDeltaRingAngle );
		FLOAT y1 = 50 * cosf( (ring+1) * fDeltaRingAngle );

		// Generate the group of segments for the current ring
		for( DWORD seg = 0; seg < (iNSphereSegments+1); seg++ )
		{
			FLOAT x0 =  r0 * sinf( seg * fDeltaSegAngle );
			FLOAT z0 =  r0 * cosf( seg * fDeltaSegAngle );
			FLOAT x1 =  r1 * sinf( seg * fDeltaSegAngle );
			FLOAT z1 =  r1 * cosf( seg * fDeltaSegAngle );

			// Add two vertices to the strip which makes up the sphere
			// (using the transformed normal to generate texture coords)
			pV->p.x = x0;
			pV->p.y = y0;
			pV->p.z = z0;
			
			pV->n = pV->p;
			D3DXVec3Normalize(&pV->n, &pV->n);
			
			pV++;


			pV->p.x = x1;
			pV->p.y = y1;
			pV->p.z = z1;

			pV->n = pV->p;
			D3DXVec3Normalize(&pV->n, &pV->n);

			pV++;
		}

	}

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pFVF	);
	SAFE_RELEASE(	m_pVs	);

	SAFE_DELETE_ARRAY(	m_pVtx	);
}


INT CShaderEx::FrameMove()
{
	float c = float( GetTickCount()) * 0.05f;

	MATA	mtY;
	MATA	mtZ;
	
	
	// ���� ��� ����
	D3DXMatrixIdentity(&m_mtWld);
	D3DXMatrixRotationY(&mtY, D3DXToRadian(-c));
	D3DXMatrixRotationZ(&mtZ, D3DXToRadian(-23.5f));

	m_mtRot = mtY * mtZ;
	m_mtWld = m_mtRot;
	
	return 0;
}


void CShaderEx::Render()
{
	HRESULT	hr=0;
	
	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE );
	
	D3DXMATRIX	mtViw;			// View Matrix
	D3DXMATRIX	mtPrj;			// Projection Matrix

	D3DXMATRIX	mtWld;			// World Matirx
	D3DXMATRIX	mtWVP;

	D3DXCOLOR	color(1, 0.6f,1,0);
	D3DXVECTOR4	vcLgt( -1,-1, 0.f, 0);

	D3DXVec4Normalize(&vcLgt, &vcLgt);


	// Get View and Projection Matrix
	m_pDev->GetTransform(D3DTS_VIEW, &mtViw);
	m_pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);

	m_pDev->SetVertexDeclaration( m_pFVF );
	m_pDev->SetVertexShader(m_pVs);

	hr = m_pTbl->SetMatrix(m_pDev, "m_mtWld", &m_mtWld);
	hr = m_pTbl->SetMatrix(m_pDev, "m_mtViw", &mtViw);
	hr = m_pTbl->SetMatrix(m_pDev, "m_mtPrj", &mtPrj);
	hr = m_pTbl->SetMatrix(m_pDev, "m_mtRot", &m_mtRot);

	hr = m_pTbl->SetVector(m_pDev, "m_LgtDir", &vcLgt);
	hr = m_pTbl->SetVector(m_pDev, "m_LgtDif", (D3DXVECTOR4*)&color);

	m_pDev->SetTexture( 0, NULL);
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP
							, m_iNvx - 2
							, m_pVtx, sizeof(CShaderEx::VtxN));

	m_pDev->SetVertexShader(NULL);
	m_pDev->SetVertexDeclaration(NULL);
}
