// Interface for the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ShaderEx_H_
#define _ShaderEx_H_

typedef D3DXVECTOR2						VEC2;
typedef	D3DXVECTOR3						VEC3;
typedef D3DXVECTOR4						VEC4;
typedef D3DXMATRIX						MATA;

typedef LPDIRECT3DDEVICE9				PDEV;

typedef LPDIRECT3DVERTEXSHADER9			PDVS;
typedef LPDIRECT3DVERTEXDECLARATION9	PDVD;
typedef LPD3DXCONSTANTTABLE				PDCT;


class CShaderEx
{
public:
	struct VtxD
	{
		VEC3	p;
		DWORD	d;
		
		VtxD()								  : p(0,0,0), d(0xFFFFFFFF){}
		VtxD(FLOAT X,FLOAT Y,FLOAT Z,DWORD D=0XFFFFFFFF): p(X,Y,Z), d(D){}

		enum {FVF = (D3DFVF_XYZ|D3DFVF_DIFFUSE),};
	};

public:
	PDEV		m_pDev;				// Device

	PDVS		m_pVs;				// Vertex Shader
	PDVD		m_pFVF;				// Declarator
	PDCT		m_pTbl;				// Constant Table

	VtxD		m_pVtx[3];			// Vertex Buffer

	
public:
	CShaderEx();
	virtual ~CShaderEx();
	
	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif
