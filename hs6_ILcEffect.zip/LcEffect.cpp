// Implementation of the CHlslEffect class.
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning( disable : 4996)


#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>

#include "ILcEffect.h"

#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }


typedef D3DXVECTOR2						VEC2;
typedef	D3DXVECTOR3						VEC3;
typedef D3DXVECTOR4						VEC4;
typedef D3DXMATRIX						MATA;

typedef LPDIRECT3DDEVICE9				PDEV;
typedef LPDIRECT3DVERTEXSHADER9			PDVS;
typedef LPDIRECT3DPIXELSHADER9			PDPS;
typedef LPDIRECT3DVERTEXDECLARATION9	PDVD;
typedef LPD3DXCONSTANTTABLE				PDCT;


class CHlslEffect : public ILcEffect
{
protected:
	PDEV		m_pDev;				// Device

	PDVS		m_pVs;				// Vertex Shader
	PDPS		m_pPs;				// Pixel Shader
	PDCT		m_pCv;				// Constant Table for Vertex Shader

	PDVD		m_pFVF;				// Declarator

	int			m_nType;			//1: File, 2:string, 3: Resource
	char		m_sShad[8];			// vs_.. or ps_...
	char		m_nShad;			//1: Vertex Shader, 2: Pixel Shader
	

public:
	CHlslEffect();
	virtual ~CHlslEffect();

	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual void	Destroy();
	virtual INT		Begin();
	virtual INT		End();

	virtual INT		SetupDecalarator(DWORD dFVF);
	
	virtual INT		SetMatrix(char* sName, D3DXMATRIX* v);
	virtual INT		SetVector(char* sName, D3DXVECTOR4* v);
	virtual INT		SetColor(char* sName, D3DXCOLOR* v);
	virtual INT		SetFloat(char* sName, FLOAT v);

	void	SetSourceType(int nSource);
	void	SetShaderType(char* sShad);
};



CHlslEffect::CHlslEffect()
{
	m_pVs	= NULL;
	m_pPs	= NULL;
	m_pCv	= NULL;
	m_pFVF	= NULL;

	m_nType	= 0;							//1: File, 2:string, 3: Resource
	memset(m_sShad, 0, sizeof m_sShad);		//vs_..: Vertex Shader, 2: ps_..:Pixel Shader
	m_nShad	= 0;
}

CHlslEffect::~CHlslEffect()
{
	Destroy();
}


INT	CHlslEffect::Create(void*p1,void*p2,void*p3,void*p4)
{
	m_pDev = (PDEV)p1;

	if(0 == m_nType)
		return -1;

	if(strlen(m_sShad)<1)
		return -1;


	if(0==_strnicmp(m_sShad, "vs", 2))
		m_nShad = 1;

	else if(0==_strnicmp(m_sShad, "ps", 2))
		m_nShad = 2;

	else
		return -1;

	HRESULT	hr;
	DWORD dwFlags = 0;

#if defined( _DEBUG ) || defined( DEBUG )
	dwFlags |= D3DXSHADER_DEBUG;
#endif

	LPD3DXBUFFER	pShd = NULL;
	LPD3DXBUFFER	pErr = NULL;
	

	// Assemble
	if(1 == m_nType)
	{
		char* sFunc = (char*)p2;
		char* sShad	= (char*)p3;
		char* sFile	= (char*)p4;

		hr = D3DXCompileShaderFromFile(
			sFile
			, NULL
			, NULL
			, sFunc
			, sShad
			, dwFlags
			, &pShd
			, &pErr
			, &m_pCv);
		
	}
	else if(2 == m_nType)
	{
		char* sFunc = (char*)p2;
		char* sShad	= (char*)p3;
		char* sStr	= (char*)p4;

		int iLen	= strlen(sStr);

		hr = D3DXCompileShader(
			sStr
			, iLen
			, NULL
			, NULL
			, sFunc
			, sShad
			, dwFlags
			, &pShd
			, &pErr
			, &m_pCv);
	}
	else if(3 == m_nType)
	{
		DWORD dResourceId	= (DWORD)p2;
		char* sFunc = (char*)p3;
		char* sShad	= (char*)p4;

		hr = D3DXCompileShaderFromResource(
			GetModuleHandle(NULL)
			, MAKEINTRESOURCE(dResourceId)
			, NULL
			, NULL
			, sFunc
			, sShad
			, dwFlags
			, &pShd
			, &pErr
			, &m_pCv);
	}

	if ( FAILED(hr) )
	{
		MessageBox( GetActiveWindow(), (char*)pErr->GetBufferPointer(), "Err", MB_ICONWARNING);
		SAFE_RELEASE(pErr);
		return -1;
	}

	// Vertex Shader
	if(1 == m_nShad)
		hr = m_pDev->CreateVertexShader( (DWORD*)pShd->GetBufferPointer() , &m_pVs);

	// Pixel Shader
	else if(2 == m_nShad)
		hr = m_pDev->CreatePixelShader( (DWORD*)pShd->GetBufferPointer() , &m_pPs);

	pShd->Release();
	if ( FAILED(hr) )
		return -1;

	return 0;
}

void CHlslEffect::Destroy()
{
	SAFE_RELEASE(	m_pCv	);
	SAFE_RELEASE(	m_pVs	);
	SAFE_RELEASE(	m_pPs	);
	SAFE_RELEASE(	m_pFVF	);
}


INT CHlslEffect::SetupDecalarator(DWORD dFVF)
{
	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};

	D3DXDeclaratorFromFVF(dFVF, vertex_decl);

	if(FAILED(m_pDev->CreateVertexDeclaration( vertex_decl, &m_pFVF )))
		return -1;

	return 0;
}

INT CHlslEffect::SetMatrix(char* sName, D3DXMATRIX* v)
{
	return m_pCv->SetMatrix(m_pDev, sName, v);
}


INT CHlslEffect::SetVector(char* sName, D3DXVECTOR4* v)
{
	return m_pCv->SetVector(m_pDev, sName, v);
}


INT CHlslEffect::SetColor(char* sName, D3DXCOLOR* v)
{
	return m_pCv->SetVector(m_pDev, sName, (D3DXVECTOR4*)v);
}

INT CHlslEffect::SetFloat(char* sName, FLOAT v)
{
	return m_pCv->SetFloat(m_pDev, sName, v);
}



INT CHlslEffect::Begin()
{
	if(m_pFVF)
		m_pDev->SetVertexDeclaration( m_pFVF );									// SetFVF


	if(m_pVs)
		m_pDev->SetVertexShader(m_pVs);											// Shader Code

	if(m_pPs)
		m_pDev->SetPixelShader(m_pPs);

	return 0;
}



INT CHlslEffect::End()
{
	if(m_pFVF)
		m_pDev->SetVertexDeclaration( NULL );									// SetFVF

	if(m_pVs)
		m_pDev->SetVertexShader(NULL);											// Shader Code

	if(m_pPs)
		m_pDev->SetPixelShader(NULL);

	return 0;
}



void CHlslEffect::SetSourceType(int nType)
{
	m_nType	= nType;
}

void CHlslEffect::SetShaderType(char* sShad)
{
	strcpy(m_sShad, sShad);
}




// sCmd: "File", "String", "Resource"
int LcHlsl_CreateShader(char* sCmd
						, ILcEffect** pData
						, void* pDevice
						, char* sFunction
						, char* sShaderMode	// Vertex shader version: "vs_1_1", Pixel Shader version: "ps_2_0", "ps.2.0", etc
						, void* v1			// File Name, or String Pointer, ResourceId
						, void* v2			// if v1 is String Pointer then this is String Length.
						)
{
	*pData	= NULL;

	//1: File, 2:string, 3: Resource
	int	nType = 0;

	if(0==_strnicmp(sCmd, "File", 4))
		nType = 1;

	else if(0==_strnicmp(sCmd, "String", 4))
		nType = 2;

	else if(0==_strnicmp(sCmd, "Resource", 4))
		nType = 3;
	
	else
		return -1;


	CHlslEffect* pObj = new CHlslEffect;
	

	pObj->SetSourceType(nType);
	pObj->SetShaderType(sShaderMode);
	if(FAILED(pObj->Create(pDevice, sFunction, sShaderMode, v1)))
	{
		delete pObj;
		return -1;
	}

	*pData = pObj;
	return 0;
}



int LcHlsl_CreateShaderFromString(char* sCmd
								, ILcEffect** pData
								, void* pDevice
								, char* sFunction
								, char* sShaderMode
								, char* sString
								, int iLen)
{
	*pData	= NULL;

	CHlslEffect*	p = new CHlslEffect;
	
	//1: File, 2:string, 3: Resource
	p->SetSourceType(2);
	if(FAILED(p->Create(pDevice, sString, (void*)iLen)))
	{
		delete p;
		return -1;

	}

	*pData = p;
	return 0;
}
