// Interface for the ILcEffect class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ILcEffect_H_
#define _ILcEffect_H_


#ifndef interface
#define interface struct
#endif


#ifndef LC_CLASS_DESTROYER
#define LC_CLASS_DESTROYER( CLASS_NAME )	\
virtual ~CLASS_NAME(){}
#endif


interface ILcEffect
{
	LC_CLASS_DESTROYER(	ILcEffect	); 

	virtual INT		Create(void* p1=NULL, void* p2=NULL,void* p3=NULL, void* p4=NULL)=0;
	virtual void	Destroy()=0;
	virtual INT		Begin()=0;
	virtual INT		End()=0;

	virtual INT		SetupDecalarator(DWORD dFVF)=0;
	virtual INT		SetMatrix(char* sName, D3DXMATRIX* v)=0;
	virtual INT		SetVector(char* sName, D3DXVECTOR4* v)=0;
	virtual INT		SetColor(char* sName, D3DXCOLOR* v)=0;
	virtual INT		SetFloat(char* sName, FLOAT v) =0;
};


// sCmd: "File", "String", "Resource"
int LcHlsl_CreateShader(char* sCmd
						, ILcEffect** pData
						, void* pDevice
						, char* sFunction
						, char* sShaderMode	// Vertex shader version: "vs_1_1", Pixel Shader version: "ps_2_0", "ps.2.0", etc
						, void* v1			// File Name, or String Pointer, ResourceId
						, void* v2 =NULL	// if v1 is String Pointer then this is String Length.
						);

#endif

