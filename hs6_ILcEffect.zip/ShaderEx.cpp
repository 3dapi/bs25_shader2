// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	
	m_pVs0	= NULL;
	m_pPs0	= NULL;

	m_pVs1	= NULL;
	m_pPs1	= NULL;

	m_pTx	= NULL;
	m_pVtx	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();	
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev	= pDev;

	if ( FAILED(LcHlsl_CreateShader("File", &m_pVs0, m_pDev, "VtxPrc0", "vs_1_1", "data/shader.fx")))
		return -1;

	if ( FAILED(LcHlsl_CreateShader("File", &m_pPs0, m_pDev, "PxlPrc0", "ps_2_0", "data/shader.fx")))
		return -1;


	if ( FAILED(LcHlsl_CreateShader("File", &m_pVs1, m_pDev, "VtxPrc1", "vs_1_1", "data/shader.fx")))
		return -1;

	if ( FAILED(LcHlsl_CreateShader("File", &m_pPs1, m_pDev, "PxlPrc1", "ps_2_0", "data/shader.fx")))
		return -1;



	m_pVs0->SetupDecalarator(VtxNDUV1::FVF);
	m_pVs1->SetupDecalarator(VtxNDUV1::FVF);



	D3DXCreateTextureFromFile(m_pDev, "Texture/earth.bmp", &m_pTx);


	// ���ؽ� ����
	INT	iNSphereSegments	= 128;
	m_iNvx = 2*iNSphereSegments*(iNSphereSegments+1);

	FLOAT fDeltaRingAngle = ( D3DX_PI / iNSphereSegments );
	FLOAT fDeltaSegAngle  = ( 2.0f * D3DX_PI / iNSphereSegments );

	m_pVtx = new VtxNDUV1[m_iNvx];
	VtxNDUV1* pVtx = m_pVtx;

	// Generate the group of rings for the sphere
	for( DWORD ring = 0; ring < iNSphereSegments; ring++ )
	{
		FLOAT r0 = 50 * sinf( (ring+0) * fDeltaRingAngle );
		FLOAT r1 = 50 * sinf( (ring+1) * fDeltaRingAngle );
		FLOAT y0 = 50 * cosf( (ring+0) * fDeltaRingAngle );
		FLOAT y1 = 50 * cosf( (ring+1) * fDeltaRingAngle );

		// Generate the group of segments for the current ring
		for( DWORD seg = 0; seg < (iNSphereSegments+1); seg++ )
		{
			FLOAT x0 =  r0 * sinf( seg * fDeltaSegAngle );
			FLOAT z0 =  r0 * cosf( seg * fDeltaSegAngle );
			FLOAT x1 =  r1 * sinf( seg * fDeltaSegAngle );
			FLOAT z1 =  r1 * cosf( seg * fDeltaSegAngle );

			// Add two vertices to the strip which makes up the sphere
			// (using the transformed normal to generate texture coords)
			pVtx->p.x = x0;
			pVtx->p.y = y0;
			pVtx->p.z = z0;
			pVtx->n.x = x0;
			pVtx->n.y = y0;
			pVtx->n.z = z0;
			
			D3DXVec3Normalize(&pVtx->n, &pVtx->n);
			
			pVtx->u = -((FLOAT)seg)/iNSphereSegments;
			pVtx->v = (ring+0)/(FLOAT)iNSphereSegments;
			pVtx++;

			pVtx->p.x = x1;
			pVtx->p.y = y1;
			pVtx->p.z = z1;
			pVtx->n.x = x1;
			pVtx->n.y = y1;
			pVtx->n.z = z1;
			
			D3DXVec3Normalize(&pVtx->n, &pVtx->n);
			pVtx->u = -((FLOAT)seg)/iNSphereSegments;
			pVtx->v = (ring+1)/(FLOAT)iNSphereSegments;
			pVtx++;
		}

	}

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_DELETE(	m_pVs0	);
	SAFE_DELETE(	m_pPs0	);

	SAFE_DELETE(	m_pVs1	);
	SAFE_DELETE(	m_pPs1	);

	SAFE_RELEASE(	m_pTx	);

	SAFE_DELETE_ARRAY(	m_pVtx	);
}


INT CShaderEx::FrameMove()
{
	static float c=0;

	c=100.f * g_pApp->m_fTime;

	if(c>360.f)
		c -=360.f;

	MATA	mtY;
	MATA	mtZ;
	
	
	// ���� ��� ����
	D3DXMatrixIdentity(&m_mtWld);
	D3DXMatrixRotationY(&mtY, D3DXToRadian(-c));
	D3DXMatrixRotationZ(&mtZ, D3DXToRadian(-23.5f));

	m_mtWld = mtY * mtZ;
	
	return 0;
}


void CShaderEx::Render()
{
	MATA		mtViw;			// View Matrix
	MATA		mtPrj;			// Projection Matrix

	m_pDev->GetTransform(D3DTS_VIEW, &mtViw);
	m_pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);

	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE );
    m_pDev->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );

	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	
	// Render
	m_pVs0->Begin();
	m_pPs0->Begin();

	// ���ؽ� ���꿡 ���� ��� ����
	D3DXVECTOR4 vcLight(1,0,0,0);		// ��������

	m_pVs0->SetMatrix("m_mtWld", &m_mtWld);
	m_pVs0->SetMatrix("m_mtViw", &mtViw);
	m_pVs0->SetMatrix("m_mtPrj", &mtPrj);
	m_pVs0->SetMatrix("m_mtRot", &m_mtWld);
	m_pVs0->SetVector("m_vcLgt", &vcLight);

	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW);

	m_pDev->SetTexture( 0, m_pTx );
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, m_iNvx - 2, m_pVtx, sizeof(VtxNDUV1));

	m_pVs0->End();
	m_pPs0->End();

	m_pVs1->Begin();
	m_pPs1->Begin();

	
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState( D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_DESTALPHA);
	m_pDev->SetRenderState( D3DRS_ZWRITEENABLE, FALSE);

	m_pVs1->SetMatrix("m_mtWld", &m_mtWld);
	m_pVs1->SetMatrix("m_mtViw", &mtViw);
	m_pVs1->SetMatrix("m_mtPrj", &mtPrj);
	m_pVs1->SetMatrix("m_mtRot", &m_mtWld);
	m_pVs1->SetVector("m_vcLgt", &vcLight);



	D3DXMATRIX mtViwI;
	D3DXMatrixInverse(&mtViwI, NULL, &mtViw);
	D3DXVECTOR4 vcGlow(m_mtWld._41 - mtViwI._41, m_mtWld._42 - mtViwI._42, m_mtWld._43 - mtViwI._43, 0); 
	D3DXVec4Normalize(&vcGlow, &vcGlow);
	m_pVs1->SetVector("g_vcGlow", &vcGlow);

	FLOAT	fThick=25.F;

	m_pVs1->SetFloat("g_fThick", fThick);

	m_pDev->SetRenderState( D3DRS_CULLMODE, D3DCULL_CW);
	m_pDev->SetTexture( 0, m_pTx );
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, m_iNvx - 2, m_pVtx, sizeof(VtxNDUV1));

	m_pDev->SetVertexShader(NULL);
	m_pDev->SetPixelShader(NULL);

	m_pDev->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE);

	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState( D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_DESTALPHA);
	m_pDev->SetRenderState( D3DRS_ZWRITEENABLE, TRUE);


	m_pVs1->End();
	m_pPs1->End();
}


