// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pPs	= NULL;
	m_pTbl	= NULL;

	m_nType	= 0;
}


CShaderEx::~CShaderEx()
{
	Destroy();	
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)pDev;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER	pShd	= NULL;
	LPD3DXBUFFER	pErr	= NULL;

	hr = D3DXCompileShaderFromFile(	"data/Shader.fx"
									, NULL
									, NULL
									, "PxlPrc"
									, "ps_2_0"
									, dwFlags
									, &pShd
									, &pErr
									, &m_pTbl
									);
	
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}

	hr = m_pDev->CreatePixelShader( (DWORD*)pShd->GetBufferPointer() , &m_pPs);
	pShd->Release();
	if ( FAILED(hr) )
		return -1;


	m_pVtx[0] = VtxD(-1.05F,  1.02F,  0, D3DXCOLOR(1,0,0,1));
	m_pVtx[1] = VtxD( 1.05F,  1.02F,  0, D3DXCOLOR(0,1,0,1));
	m_pVtx[2] = VtxD( 1.05F, -1.02F,  0, D3DXCOLOR(0,0,1,1));
	m_pVtx[3] = VtxD(-1.05F, -1.02F,  0, D3DXCOLOR(1,0,1,1));

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pPs	);
	SAFE_RELEASE(	m_pTbl	);
}


INT CShaderEx::FrameMove()
{
	return 0;
}

void CShaderEx::Render()
{
	HRESULT hr= 0;

	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	
	m_pDev->SetPixelShader(m_pPs);

	// �ȼ� shader ���� ���� �� ����
	hr = m_pTbl->SetInt(m_pDev, "g_nPxlPrc", m_nType);

	m_pDev->SetFVF(VtxD::FVF);
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxD));

	m_pDev->SetPixelShader(NULL);
}

INT CShaderEx::GetType()
{
	return m_nType;
}

void CShaderEx::SetType(int nType)
{
	m_nType = nType;
}