// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pVs	= NULL;
	m_pFVF	= NULL;
	m_pTbl	= NULL;

	m_pVtx	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();	
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)pDev;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER	pShd	= NULL;
	LPD3DXBUFFER	pErr	= NULL;

	hr = D3DXCompileShaderFromFile(	"data/Shader.fx"
								,	NULL
								,	NULL
								,	"VtxPrc"
								,	"vs_1_1"
								,	dwFlags
								,	&pShd
								,	&pErr
								,	&m_pTbl
								);

	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}

	hr = m_pDev->CreateVertexShader( (DWORD*)pShd->GetBufferPointer() , &m_pVs);
	pShd->Release();
	if ( FAILED(hr) )
		return -1;


	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(VtxD::FVF, vertex_decl);
	if(FAILED(m_pDev->CreateVertexDeclaration( vertex_decl, &m_pFVF )))
		return -1;

	



	// ���ؽ� ����
	INT	iNSphereSegments	= 128;
	m_iNvx = 2*iNSphereSegments*(iNSphereSegments+1);

	FLOAT fDeltaRingAngle = ( D3DX_PI / iNSphereSegments );
	FLOAT fDeltaSegAngle  = ( 2.0f * D3DX_PI / iNSphereSegments );

	m_pVtx = new VtxD[m_iNvx];
	VtxD* pVtx = m_pVtx;

	// Generate the group of rings for the sphere
	for( DWORD ring = 0; ring < iNSphereSegments; ring++ )
	{
		FLOAT r0 = 50 * sinf( (ring+0) * fDeltaRingAngle );
		FLOAT r1 = 50 * sinf( (ring+1) * fDeltaRingAngle );
		FLOAT y0 = 50 * cosf( (ring+0) * fDeltaRingAngle );
		FLOAT y1 = 50 * cosf( (ring+1) * fDeltaRingAngle );

		// Generate the group of segments for the current ring
		for( DWORD seg = 0; seg < (iNSphereSegments+1); seg++ )
		{
			FLOAT x0 =  r0 * sinf( seg * fDeltaSegAngle );
			FLOAT z0 =  r0 * cosf( seg * fDeltaSegAngle );
			FLOAT x1 =  r1 * sinf( seg * fDeltaSegAngle );
			FLOAT z1 =  r1 * cosf( seg * fDeltaSegAngle );

			// Add two vertices to the strip which makes up the sphere
			// (using the transformed normal to generate texture coords)
			pVtx->p.x = x0;
			pVtx->p.y = y0;
			pVtx->p.z = z0;
			pVtx++;

			pVtx->p.x = x1;
			pVtx->p.y = y1;
			pVtx->p.z = z1;
			pVtx++;
		}
	}


	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pFVF	);
	SAFE_RELEASE(	m_pVs	);

	SAFE_DELETE_ARRAY(	m_pVtx	);
}


INT CShaderEx::FrameMove()
{
	D3DXMATRIX	mtY;
	D3DXMATRIX	mtZ;
	FLOAT	c = GetTickCount() * 0.05f;

	// ���� ��� ����
	D3DXMatrixIdentity(&m_mtWld);
	D3DXMatrixRotationY(&mtY, D3DXToRadian(-c));
	D3DXMatrixRotationZ(&mtZ, D3DXToRadian(-23.5f));

	m_mtWld = mtY * mtZ;
	
	return 0;
}


void CShaderEx::Render()
{
	HRESULT	hr=0;
	
	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE );


	D3DXMATRIX		mtViw;			// View Matrix
	D3DXMATRIX		mtPrj;			// Projection Matrix

	D3DXCOLOR	FogColor(1.0F, 1.0F, 0.2F, 1);	// Fog Color
	FLOAT		FogEnd	= 120.f;	// Fog End
	FLOAT		FogBgn	= 0.f;		// Fog Begin
	
	m_pDev->GetTransform(D3DTS_VIEW, &mtViw);
	m_pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);

	// Render
	m_pDev->SetVertexShader(m_pVs);
	m_pDev->SetVertexDeclaration( m_pFVF );

	hr = m_pTbl->SetMatrix(m_pDev, "m_mtWorld", &m_mtWld);
	hr = m_pTbl->SetMatrix(m_pDev, "m_mtView", &mtViw);
	hr = m_pTbl->SetMatrix(m_pDev, "m_mtProj", &mtPrj);
	hr = m_pTbl->SetVector(m_pDev, "m_FogColor", (D3DXVECTOR4*)&FogColor);
	hr = m_pTbl->SetFloat(m_pDev, "m_FogEnd", FogEnd);
	hr = m_pTbl->SetFloat(m_pDev, "m_FogBgn", FogBgn);
	

	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, m_iNvx - 2, m_pVtx, sizeof(VtxD));

	m_pDev->SetVertexShader( NULL);
	m_pDev->SetVertexDeclaration( NULL );
}


