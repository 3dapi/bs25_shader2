// Interface for the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ShaderEx_H_
#define _ShaderEx_H_

typedef	D3DXVECTOR3						VEC3;

typedef LPDIRECT3DDEVICE9				PDEV;
typedef LPDIRECT3DVERTEXSHADER9			PDVS;
typedef LPDIRECT3DVERTEXDECLARATION9	PDVD;


class CShaderEx
{
public:
	struct Vtx
	{
		VEC3	p;
		
		Vtx()					  : p(0,0,0){}
		Vtx(FLOAT X,FLOAT Y,FLOAT Z) : p(X,Y,Z){}

		enum {FVF = (D3DFVF_XYZ),};
	};

public:
	PDEV		m_pDev;				// Device

	PDVS		m_pVs;				// Vertex Shader
	PDVD		m_pFVF;				// Declarator

	Vtx			m_pVtx[3];			// Vertex Buffer

	
public:
	CShaderEx();
	virtual ~CShaderEx();
	
	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();
};

#endif
