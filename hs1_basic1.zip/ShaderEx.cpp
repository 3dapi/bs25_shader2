// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pVs	= NULL;
	m_pFVF	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)pDev;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;


	const char sHlsl[] =
	"float4 VtxPrc(float3 Pos : POSITION) : POSITION	\n"
	"{													\n"
	"    return float4(Pos, 1);							\n"
	"}													\n"
	"													\n"
	;


	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER	pShd	= NULL;
	LPD3DXBUFFER	pErr	= NULL;
	INT				iLen	= strlen(sHlsl);
	hr = D3DXCompileShader(	sHlsl
						,	iLen
						,	NULL
						,	NULL
						,	"VtxPrc"	// ���� �Լ�
						,	"vs_1_1"	// shader ����
						,	dwFlags
						,	&pShd
						,	&pErr
						,	NULL
						);

	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}

	hr = m_pDev->CreateVertexShader( (DWORD*)pShd->GetBufferPointer() , &m_pVs);
	pShd->Release();
	if ( FAILED(hr) )
		return -1;


	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(Vtx::FVF, vertex_decl);
	if(FAILED(m_pDev->CreateVertexDeclaration( vertex_decl, &m_pFVF )))
		return -1;



	m_pVtx[0] = Vtx(-1,-1,  0);
	m_pVtx[1] = Vtx( 0, 1,  0);
	m_pVtx[2] = Vtx( 1,-1,  0);

	return 0;
}


void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pFVF	);
	SAFE_RELEASE(	m_pVs	);
}


INT CShaderEx::FrameMove()
{
	return 0;
}


void CShaderEx::Render()
{
	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE );

	
	// Render
	m_pDev->SetVertexShader(m_pVs);
	m_pDev->SetVertexDeclaration( m_pFVF );


	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLELIST, 1, m_pVtx, sizeof(Vtx));

	m_pDev->SetVertexShader(NULL);
	m_pDev->SetVertexDeclaration(NULL);
}