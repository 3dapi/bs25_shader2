// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pVs	= NULL;
	m_pFVF	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)pDev;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER	pShd	= NULL;
	LPD3DXBUFFER	pErr	= NULL;

	hr = D3DXCompileShaderFromFile(	"data/Shader.fx"
								,	NULL
								,	NULL
								,	"VtxPrc"	// shader ���� �Լ�
								,	"vs_1_1"	// shader ����
								,	dwFlags
								,	&pShd
								,	&pErr
								,	&m_pTbl		// ��� ���̺� ��ȯ
								);

	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}

	hr = m_pDev->CreateVertexShader( (DWORD*)pShd->GetBufferPointer() , &m_pVs);
	pShd->Release();
	if ( FAILED(hr) )
		return -1;


	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(VtxD::FVF, vertex_decl);
	if(FAILED(m_pDev->CreateVertexDeclaration( vertex_decl, &m_pFVF )))
		return -1;



	m_pVtx[0] = VtxD(-1,-1,  0, D3DXCOLOR(1,0,0,1));
	m_pVtx[1] = VtxD( 0, 1,  0, D3DXCOLOR(0,1,0,1));
	m_pVtx[2] = VtxD( 1,-1,  0, D3DXCOLOR(0,0,1,1));

	return 0;
}


void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pFVF	);
	SAFE_RELEASE(	m_pVs	);
}


INT CShaderEx::FrameMove()
{
	return 0;
}


void CShaderEx::Render()
{
	// Render
	m_pDev->SetVertexShader(m_pVs);
	m_pDev->SetVertexDeclaration( m_pFVF );


	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLELIST, 1, m_pVtx, sizeof(VtxD));

	m_pDev->SetVertexShader( NULL);
}