// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pTx	= NULL;
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)pDev;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;

	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER	pShd	= NULL;
	LPD3DXBUFFER	pErr	= NULL;

	// �ؼ� shader ������
	hr = D3DXCompileShaderFromFile(	"data/shader.fx"
									, NULL
									, NULL
									, "TxlPrc"
									, "tx_1_0"
									, dwFlags
									, &pShd
									, &pErr
									, NULL
									);
	
	
	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}

	
	// ������ �ؽ�ó(procedural texture) ����
	if(FAILED(D3DXCreateTexture(m_pDev, 128, 128, 1, 0, D3DFMT_UNKNOWN, D3DPOOL_MANAGED, &m_pTx)))
		return -1;


	// �ؽ�ó �ȼ� ä���
	//if( FAILED(D3DXFillTextureTX(m_pTx, (DWORD*)pShd->GetBufferPointer(), NULL, 0)))
	//	return -1;

	//pShd->Release();


	LPD3DXTEXTURESHADER pTs = NULL;
	D3DXCreateTextureShader( (DWORD*)pShd->GetBufferPointer(), &pTs);
	pShd->Release();

	// �ؽ�ó �ȼ� ä���
    if( FAILED(D3DXFillTextureTX(m_pTx, pTs)))
		return -1;

	pTs->Release();



	// ���� ����
	m_pVtx[0] = VtxDUV1(-1.05F,  1.02F,  0,  0, 0);
	m_pVtx[1] = VtxDUV1( 1.05F,  1.02F,  0,  1, 0);
	m_pVtx[2] = VtxDUV1( 1.05F, -1.02F,  0,  1, 1);
	m_pVtx[3] = VtxDUV1(-1.05F, -1.02F,  0,  0, 1);

	return 0;
}

void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pTx	);
}


INT CShaderEx::FrameMove()
{
	return 0;
}


void CShaderEx::Render()
{
	HRESULT		hr=-1;

	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE );

	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_NONE);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_NONE);
    
	m_pDev->SetTexture( 0, m_pTx );
	m_pDev->SetFVF(VtxDUV1::FVF);
	m_pDev->DrawPrimitiveUP( D3DPT_TRIANGLEFAN, 2, m_pVtx, sizeof(VtxDUV1));

}