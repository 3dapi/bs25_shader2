// Implementation of the CShaderEx class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CShaderEx::CShaderEx()
{
	m_pDev	= NULL;
	m_pVs	= NULL;
	m_pFVF	= NULL;
	m_pTbl	= NULL;

	FLOAT	fSize = 30;

	// front
	m_pVtx[ 0] = VtxD(-1.f, -1.f, -1.f, D3DXCOLOR(1.0F, 0.0F, 0.0F, 1.0F) );
	m_pVtx[ 1] = VtxD(-1.f,  1.f, -1.f, D3DXCOLOR(0.0F, 1.0F, 0.0F, 1.0F) );
	m_pVtx[ 2] = VtxD( 1.f,  1.f, -1.f, D3DXCOLOR(0.0F, 0.0F, 1.0F, 1.0F) );
	m_pVtx[ 3] = VtxD( 1.f, -1.f, -1.f, D3DXCOLOR(1.0F, 0.0F, 1.0F, 1.0F) );

	// back
	m_pVtx[ 4] = VtxD(-1.f, -1.f,  1.f, D3DXCOLOR(1.0F, 1.0F, 0.0F, 1.0F) );
	m_pVtx[ 5] = VtxD( 1.f, -1.f,  1.f, D3DXCOLOR(0.0F, 1.0F, 1.0F, 1.0F) );
	m_pVtx[ 6] = VtxD( 1.f,  1.f,  1.f, D3DXCOLOR(1.0F, 0.0F, 0.0F, 1.0F) );
	m_pVtx[ 7] = VtxD(-1.f,  1.f,  1.f, D3DXCOLOR(1.0F, 0.0F, 1.0F, 1.0F) );

	// top
	m_pVtx[ 8] = VtxD(-1.f,  1.f, -1.f, D3DXCOLOR(0.0F, 0.0F, 1.0F, 1.0F) );
	m_pVtx[ 9] = VtxD(-1.f,  1.f,  1.f, D3DXCOLOR(0.0F, 1.0F, 0.0F, 1.0F) );
	m_pVtx[10] = VtxD( 1.f,  1.f,  1.f, D3DXCOLOR(1.0F, 0.0F, 1.0F, 1.0F) );
	m_pVtx[11] = VtxD( 1.f,  1.f, -1.f, D3DXCOLOR(0.0F, 1.0F, 1.0F, 1.0F) );

	// bottom
	m_pVtx[12] = VtxD(-1.f, -1.f, -1.f, D3DXCOLOR(1.0F, 1.0F, 0.0F, 1.0F) );
	m_pVtx[13] = VtxD( 1.f, -1.f, -1.f, D3DXCOLOR(0.0F, 1.0F, 0.0F, 1.0F) );
	m_pVtx[14] = VtxD( 1.f, -1.f,  1.f, D3DXCOLOR(0.0F, 0.0F, 1.0F, 1.0F) );
	m_pVtx[15] = VtxD(-1.f, -1.f,  1.f, D3DXCOLOR(1.0F, 0.0F, 0.0F, 1.0F) );

	// left
	m_pVtx[16] = VtxD(-1.f, -1.f,  1.f, D3DXCOLOR(1.0F, 1.0F, 0.0F, 1.0F) );
	m_pVtx[17] = VtxD(-1.f,  1.f,  1.f, D3DXCOLOR(1.0F, 0.0F, 1.0F, 1.0F) );
	m_pVtx[18] = VtxD(-1.f,  1.f, -1.f, D3DXCOLOR(0.0F, 1.0F, 1.0F, 1.0F) );
	m_pVtx[19] = VtxD(-1.f, -1.f, -1.f, D3DXCOLOR(1.0F, 0.0F, 1.0F, 1.0F) );

	// right
	m_pVtx[20] = VtxD( 1.f, -1.f, -1.f, D3DXCOLOR(1.0F, 1.0F, 0.0F, 1.0F) );
	m_pVtx[21] = VtxD( 1.f,  1.f, -1.f, D3DXCOLOR(0.0F, 1.0F, 0.0F, 1.0F) );
	m_pVtx[22] = VtxD( 1.f,  1.f,  1.f, D3DXCOLOR(1.0F, 0.0F, 1.0F, 1.0F) );
	m_pVtx[23] = VtxD( 1.f, -1.f,  1.f, D3DXCOLOR(0.0F, 0.0F, 1.0F, 1.0F) );


	for(int i=0; i<24; ++i)
	{
		m_pVtx[i].p *=fSize;
	}

	// front
	m_pIdx[ 0] = VtxIdx( 0,  1,  2);
	m_pIdx[ 1] = VtxIdx( 0,  2,  3);

	// back
	m_pIdx[ 2] = VtxIdx( 4,  5,  6);
	m_pIdx[ 3] = VtxIdx( 4,  6,  7);

	// top
	m_pIdx[ 4] = VtxIdx( 8,  9, 10);
	m_pIdx[ 5] = VtxIdx( 8, 10, 11);

	// bottom
	m_pIdx[ 6] = VtxIdx(12, 13, 14);
	m_pIdx[ 7] = VtxIdx(12, 14, 15);

	// left
	m_pIdx[ 8] = VtxIdx(16, 17, 18);
	m_pIdx[ 9] = VtxIdx(16, 18, 19);

	// right
	m_pIdx[10] = VtxIdx(20, 21, 22);
	m_pIdx[11] = VtxIdx(20, 22, 23);
}


CShaderEx::~CShaderEx()
{
	Destroy();
}


INT CShaderEx::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev = (PDEV)pDev;

	HWND	hWnd;
	D3DDEVICE_CREATION_PARAMETERS ppm;
	m_pDev->GetCreationParameters(&ppm);
	hWnd	= ppm.hFocusWindow;



	DWORD dwFlags = 0;
	#if defined( _DEBUG ) || defined( DEBUG )
		dwFlags |= D3DXSHADER_DEBUG;
	#endif

	LPD3DXBUFFER	pShd	= NULL;
	LPD3DXBUFFER	pErr	= NULL;

	hr = D3DXCompileShaderFromFile(	"data/shader.fx"
								,	NULL
								,	NULL
								,	"VtxPrc"	// ���� �Լ�
								,	"vs_1_1"	// shader ����
								,	dwFlags
								,	&pShd
								,	&pErr
								,	&m_pTbl		// ��� ���̺�
								);

	if ( FAILED(hr) )
	{
		char sErr[2048]={0};
		if(pErr)
		{
			char* s=(char*)pErr->GetBufferPointer();
			sprintf(sErr, s);
		}
		else
		{
			sprintf(sErr, "Cannot Compile Shader.");
		}

		MessageBox(hWnd, sErr, "Err", MB_ICONEXCLAMATION);
		return -1;
	}

	hr = m_pDev->CreateVertexShader( (DWORD*)pShd->GetBufferPointer() , &m_pVs);
	pShd->Release();
	if ( FAILED(hr) )
		return -1;


	D3DVERTEXELEMENT9 vertex_decl[MAX_FVF_DECL_SIZE]={0};
	D3DXDeclaratorFromFVF(VtxD::FVF, vertex_decl);
	if(FAILED(m_pDev->CreateVertexDeclaration( vertex_decl, &m_pFVF )))
		return -1;

	return 0;
}


void CShaderEx::Destroy()
{
	SAFE_RELEASE(	m_pTbl	);
	SAFE_RELEASE(	m_pFVF	);
	SAFE_RELEASE(	m_pVs	);
}


INT CShaderEx::FrameMove()
{
	D3DXMATRIX	mtRotX;			// Rotation Matrix X
	D3DXMATRIX	mtRotY;			// Rotation Matrix Y
	D3DXMATRIX	mtRotZ;			// Rotation Matrix Z

	
	// ȸ���ϴ� ���� ��� ����
	FLOAT		fAngle = D3DXToRadian(GetTickCount() * 0.1f);
	D3DXMatrixRotationY(&mtRotY, fAngle*3.f);
	D3DXMatrixRotationZ(&mtRotZ, fAngle*2.f);
	D3DXMatrixRotationX(&mtRotX, fAngle*1.f);

	m_mtWld = mtRotY * mtRotZ * mtRotX;
	m_mtWld._42 = 40.f;
	m_mtWld._43 = -30.f;

	return 0;
}


void CShaderEx::Render()
{
	MATA		mtWld;			// World Matrix
	MATA		mtViw;			// View Matrix
	MATA		mtPrj;			// Projection Matrix

	D3DXMatrixIdentity(&mtWld);

	m_pDev->GetTransform(D3DTS_VIEW, &mtViw);
	m_pDev->GetTransform(D3DTS_PROJECTION, &mtPrj);


	// Render
	m_pDev->SetVertexShader(m_pVs);
	m_pDev->SetVertexDeclaration( m_pFVF );

	// ��� ����: ��� ���̺� ���
	m_pTbl->SetMatrix(m_pDev, "m_mtWld", &m_mtWld);
	m_pTbl->SetMatrix(m_pDev, "m_mtViw", &mtViw);
	m_pTbl->SetMatrix(m_pDev, "m_mtPrj", &mtPrj);

	m_pDev->DrawIndexedPrimitiveUP( D3DPT_TRIANGLELIST, 0, 24, 12, m_pIdx, D3DFMT_INDEX16, m_pVtx, sizeof(VtxD));

	m_pDev->SetVertexShader( NULL);
}